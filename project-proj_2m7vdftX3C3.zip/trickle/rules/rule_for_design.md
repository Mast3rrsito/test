When designing UI elements
- Buttons should have rounded corners (pill shape preferred for main nav) and thick outlines (border-2).
- Do not use arrows or extra icons in simple navigation buttons unless requested.
- Avoid "weird panels" or unnecessary complex central widgets between titles; keep the layout clean.